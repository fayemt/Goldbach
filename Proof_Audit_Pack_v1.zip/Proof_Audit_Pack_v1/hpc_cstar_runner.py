#!/usr/bin/env python3
"""
hpc_cstar_runner.py
- Orchestrates certified bounds for C* over a (q,X,L) grid.
- Uses two methods: (A) exact eigensolver (small sizes), (B) iterative power method with residual.
- Can do early abort (threshold breach) and checkpointing.
- Designed to be swapped to an Arb-backed interval version by swapping kernel and lin-alg backends.
"""
import os, sys, json, time, math, argparse, csv, numpy as np
from tqdm import tqdm

# You can swap this import to a different, optimized module on HPC
import kuz_exact as KE

def spectral_norm_bounds(K: np.ndarray):
    """Return (lam_max_approx, row_col_bound) where row_col_bound = sqrt(||K||_1 ||K||_inf)."""
    w = np.linalg.eigvalsh(K.real)
    lam = float(w[-1])
    row_sum = np.max(np.sum(np.abs(K), axis=1))
    col_sum = np.max(np.sum(np.abs(K), axis=0))
    rc = float(math.sqrt(row_sum * col_sum))
    return lam, rc

def power_method(A, iters=500, tol=1e-12, report_every=10, lam_threshold=None):
    X = A.shape[0]
    rng = np.random.default_rng(42)
    x = rng.standard_normal(X) + 1j*rng.standard_normal(X)
    x /= np.linalg.norm(x)
    lam_old = 0.0
    for it in range(1, iters+1):
        y = A @ x
        lam = float(np.vdot(x, y).real)
        x = y / (np.linalg.norm(y) + 1e-300)
        if it % report_every == 0:
            tqdm.write(f"[power] iter={it:4d}  lambda~{lam:.6e}")
            if lam_threshold is not None and lam > lam_threshold:
                tqdm.write(f"[power] EARLY-FAIL: lambda {lam:.6e} > threshold {lam_threshold:.6e}")
                return lam, it, False
        if abs(lam - lam_old) < tol*max(1.0, abs(lam)):
            tqdm.write(f"[power] converged in {it} iters: lambda~{lam:.6e}")
            return lam, it, True
        lam_old = lam
    tqdm.write(f"[power] max iters reached: lambda~{lam:.6e}")
    return lam, iters, False

def run_case(q:int, X:int, L:int, mode:str, iters:int, tol:float, cstar_thresh:float, out_writer, out_file, checkpoint):
    t0 = time.time()
    K = KE.build_kernel(q,X,L)
    # Method A: dense eigensolver (exact for this K)
    if mode == "exact":
        lam, rc = spectral_norm_bounds(K)
        Cstar = lam / (X + L*L)
        out_writer.writerow([q,X,L,"exact",f"{lam:.8e}",f"{rc:.8e}",f"{Cstar:.8e}",f"{time.time()-t0:.2f}"])
        out_file.flush()
        try:
            os.fsync(out_file.fileno())
        except Exception:
            pass
        from tqdm import tqdm as _tq
        _tq.write(f"[case q={q} X={X} L={L}] C*={Cstar:.6e} (lambda={lam:.6e})")
        if cstar_thresh is not None and Cstar > cstar_thresh:
            tqdm.write(f"[case q={q} X={X} L={L}] EARLY-FAIL C*={Cstar:.6e} > {cstar_thresh:.6e}")
            checkpoint["early_fail"] = True
        return lam, Cstar
    # Method B: power method with live updates
    lam_thresh = cstar_thresh * (X + L*L) if cstar_thresh is not None else None
    lam, iters_done, ok = power_method(K, iters=iters, tol=tol, report_every=max(5,iters//20), lam_threshold=lam_thresh)
    Cstar = lam / (X + L*L)
    out_writer.writerow([q,X,L,"power",f"{lam:.8e}","",f"{Cstar:.8e}",f"{time.time()-t0:.2f}"])
    out_file.flush()
    try:
        os.fsync(out_file.fileno())
    except Exception:
        pass
    from tqdm import tqdm as _tq
    _tq.write(f"[case q={q} X={X} L={L}] C*={Cstar:.6e} (lambda={lam:.6e})")
    if cstar_thresh is not None and Cstar > cstar_thresh:
        tqdm.write(f"[case q={q} X={X} L={L}] EARLY-FAIL C*={Cstar:.6e} > {cstar_thresh:.6e}")
        checkpoint["early_fail"] = True
    return lam, Cstar

def main():
    ap = argparse.ArgumentParser(description="HPC C* certification runner (skeleton)")
    ap.add_argument("--q", default="3,4,5,6,7,8,9,10,11,12")
    ap.add_argument("--X", default="24,32,48,64")
    ap.add_argument("--L", default="48,64,96,128")
    ap.add_argument("--mode", choices=["exact","power"], default="power")
    ap.add_argument("--iters", type=int, default=300)
    ap.add_argument("--tol", type=float, default=1e-12)
    ap.add_argument("--cstar_threshold", type=float, default=None, help="early abort if C* exceeds this")
    ap.add_argument("--out", default="cstar_scan.csv")
    ap.add_argument("--checkpoint", default="checkpoint.json")
    args = ap.parse_args()

    qs = [int(x) for x in args.q.split(",") if x.strip()]
    Xs = [int(x) for x in args.X.split(",") if x.strip()]
    Ls = [int(x) for x in args.L.split(",") if x.strip()]

    # Load checkpoint if present
    ck = {"done": set(), "early_fail": False}
    if os.path.exists(args.checkpoint):
        try:
            data = json.load(open(args.checkpoint,"r"))
            ck["done"] = set(tuple(x) for x in data.get("done", []))
            ck["early_fail"] = bool(data.get("early_fail", False))
        except Exception:
            pass

    with open(args.out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["q","X","L","mode","lambda","rowcol_bound","Cstar","seconds"])
        f.flush()
        try:
            os.fsync(f.fileno())
        except Exception:
            pass
        total = len(qs)*len(Xs)*len(Ls)
        pbar = tqdm(total=total, desc="Grid", ncols=80)
        for q in qs:
            for X in Xs:
                for L in Ls:
                    key = (q,X,L)
                    if key in ck["done"]:
                        pbar.update(1); continue
                    tqdm.write(f"[case] q={q} X={X} L={L}")
                    lam, Cstar = run_case(q,X,L,args.mode,args.iters,args.tol,args.cstar_threshold,w,f,ck)
                    ck["done"].add(key)
                    json.dump({"done": list(ck["done"]), "early_fail": ck["early_fail"]},
                              open(args.checkpoint,"w"))
                    pbar.update(1)
                    if ck["early_fail"]:
                        tqdm.write("[runner] Early fail flagged; stopping.")
                        pbar.close()
                        return
        pbar.close()
    tqdm.write("[runner] Finished grid.")

if __name__ == "__main__":
    main()
