# HPC C* Certification — How to run and harden

This is a correctness-first skeleton for certifying the geometric-kernel spectral constant
```
C*(q;X,L) = ||K_q||_2 / (X + L^2),
K_q(m,n) = ∑_{c in [L/2,2L]} S(m,n;cq)/(cq) * W( 4π√(mn)/(cq) ).
```
## What you have *now*
- `kuz_exact.py` — **actual kernel** implementation with the true Kuznetsov geometric kernel. It uses a naive
  exact Kloosterman construction via unit loops. It's slow but correct and ideal for testing.
- `hpc_cstar_runner.py` — orchestrates a (q,X,L) grid with a progress bar, iteratively reports `λ` during the power method,
  supports early abort with `--cstar_threshold`, and logs results to CSV + checkpoint JSON.

## What to swap on a supercomputer
1. **Kloosterman sums (`S`)**  
   Replace the naive loop with a multiplicative prime-power routine (exact) using precomputed factorisations of `M=cq`.
   This drops cost from O(φ(M)·X²) to roughly O(X² · polylog M) per c.

2. **Interval arithmetic for `W`**  
   Use Arb/MPFR to evaluate the bump `W(u)` with **intervals** and directed rounding. Produce enclosures for each weight so
   that every kernel entry `K[m,n]` is an interval; the final spectral bound must be computed from those intervals.

3. **Certified spectral-norm bound**  
   Use two independent methods and take the *smaller* upper bound:
   - (A) **Interval power/Lanczos with residual certificate:** compute a Rayleigh quotient interval `r` and residual norm `ρ`;
     for Hermitian `K`, an eigenvalue lies in `[r-ρ, r+ρ]`, so `r+ρ` is a certified upper bound.
   - (B) **Row/column bound with intervals:** `||K||_2 ≤ √(||K||_1 ||K||_∞)`; compute interval row/col sums on `|K|`
     to get an explicit enclosure. Tighten with **block Gershgorin** if needed.

4. **Parallelism**  
   - Outer grid over `(q,X,L)` is embarrassingly parallel.
   - Inner `c`-sum can be threaded.
   - If using power/Lanczos, implement a matrix–vector apply `y = Kx` without materialising `K` (stream over `c` and `d`).

## Progress & Early-Fail
- `hpc_cstar_runner.py` prints live `λ` approximations every few iterations in power mode.
- `--cstar_threshold` aborts if `C*` crosses a line you set (e.g., 0.01149 from the ledger).
- Checkpointing writes `checkpoint.json` after each case so large grids can resume.

## Sanity checklist
- Hermitian symmetry: `(K - K*)` max entry < 1e-12 in floating runs; intervals should include 0 symmetrically.
- Support: `W` zeroes contributions outside `[L/2,2L]` in `c` automatically; verify with unit tests.
- Reproduce small cases with both methods (dense eig and power) and ensure upper bounds match within 1e-8 before moving to intervals.
