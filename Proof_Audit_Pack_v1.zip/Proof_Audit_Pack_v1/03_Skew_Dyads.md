# 03 — Skew Dyads (finite shapes, small factor)

Let `A ≤ B ≤ C` with `A B C ≈ N`. Split into a finite set of shapes (mild skew; A≪B≈C; A≈B≪C). For each shape:
- choose `L` to match the observed `√(mn)` scale in the weight `W(4π√(mn)/(cq))`,
- apply the same argument as in the balanced case.

**Result:** a small global factor
```
skew_factor ≤ 1.15  (you may use 1.25 for extra headroom).
```
You can fold this into `K_coeff` or keep it separate in the ledger.
