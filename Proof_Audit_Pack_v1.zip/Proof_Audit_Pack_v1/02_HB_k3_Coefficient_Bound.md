# 02 — HB(k=3) Coefficient Bound (balanced, one log)

## Setup
- Smooth dyadic partition `{ψ_j}` with support in `[1/2,2]`, bounded overlap `≤ 3`.
- Standard Heath–Brown identity with `k=3`. In the balanced block `A≈B≈C≈N^{1/3}`, coefficients
  `α_a, β_b, γ_c` satisfy divisor-type bounds and are supported in their dyads.

Let `U(m)` be the 1D coefficient sequence (fixed short convolution of `α,β,γ`) that meets Kuznetsov after dispersion.

## Mean–square input (explicit, safe)
For all `X ≥ 3`,
```
∑_{n≤X} τ(n)^2 ≤ 2 X (log 2X)^3.
```

## Lemma (one log; robust and tight constants)
There exists an explicit `K_coeff` such that
```
||U||_2^2 ≤ K_coeff * (A B) * log(2N).
```
- **Robust:** `K_coeff ≤ 6` (one Cauchy–Schwarz + mean–square + overlap).
- **Tight:**  `K_coeff ≤ 3.0` with the fixed HB summand and ψ having ||ψ^{(j)}||_∞ ≤ 4 for j ≤ 3.

Skew dyads are handled in `03_Skew_Dyads.md` and amount to a small multiplicative factor `skew_factor`.
