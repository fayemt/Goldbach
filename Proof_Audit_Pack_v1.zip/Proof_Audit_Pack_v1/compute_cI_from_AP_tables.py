#!/usr/bin/env python3
import argparse, pandas as pd, re, io, math, json
from tqdm import tqdm

def read_c_constants(path):
    df = pd.read_csv(path, sep=r"\s+")
    if "#q" in df.columns:
        df = df.rename(columns={"#q":"q"})
    return df

def read_x0(path):
    text = open(path, "r", encoding="utf-8", errors="ignore").read()
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    header = lines[0]
    cols = [c.strip().lstrip("#") for c in re.split(r"[,\s]+", header) if c.strip()]
    rows = [re.split(r"[\s,]+", ln) for ln in lines[1:]]
    norm_rows = [r[:len(cols)] for r in rows if len(r)>=len(cols)]
    df = pd.DataFrame(norm_rows, columns=cols).apply(pd.to_numeric, errors="ignore")
    for col in df.columns:
        if col != "q":
            try: df[col] = pd.to_numeric(df[col])
            except: pass
    return df

def main():
    ap = argparse.ArgumentParser(description="Recompute c_I band from AP tables and report thresholds")
    ap.add_argument("--cfile", default="c_all_rounded.txt", help="AP constants table")
    ap.add_argument("--x0file", default="x0-all-xm-xe.txt", help="AP x0 thresholds")
    ap.add_argument("--palette", default="3-12", help="levels to include, e.g., 3-12")
    ap.add_argument("--cI_base", type=float, default=0.33403, help="baseline c_I from Type-I derivation with this W")
    args = ap.parse_args()

    qmin,qmax = [int(x) for x in args.palette.split("-")]
    cdf = read_c_constants(args.cfile)
    xdf = read_x0(args.x0file)

    cdf = cdf[(cdf["q"]>=qmin) & (cdf["q"]<=qmax)].copy()
    xdf = xdf[(xdf["q"]>=qmin) & (xdf["q"]<=qmax)].copy()

    N_min = int(xdf["xpsi"].max()) if "xpsi" in xdf.columns else None
    shp = (math.log(N_min)**3) / (N_min**(1.0/3.0)) if N_min else float("nan")

    c_theta_max = float(cdf["c_theta"].max())
    # crude over-counted union bound (sum worst across palette)
    rel_penalty_upper = (qmax-qmin+1) * c_theta_max  # << 1
    cI_lower = args.cI_base * max(0.0, 1.0 - rel_penalty_upper)

    print(json.dumps({
        "N_min": N_min,
        "shape_factor_at_Nmin": shp,
        "c_theta_max": c_theta_max,
        "rel_penalty_upper_union": rel_penalty_upper,
        "cI_base": args.cI_base,
        "cI_lower_bound_conservative": cI_lower
    }, indent=2))

if __name__ == "__main__":
    main()
