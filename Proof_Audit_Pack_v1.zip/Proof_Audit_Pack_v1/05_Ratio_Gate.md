# 05 — Ratio Gate (single inequality to check)

For all shapes and q in the palette, the Type-II tail obeys
```
TypeII(N) ≤ C*_max * K_coeff * skew_factor * N^{2/3} * log N.
```
Comparing to `Margin(N) ≥ c_I * N / (log N)^2`, the decisive ratio is
```
R(N) = (C*_max * K_coeff * skew_factor / c_I) * ( (log N)^3 / N^{1/3} ).
```
The factor `(log N)^3 / N^{1/3}` is **strictly decreasing** for `N ≥ e^9 ≈ 8103`, hence on our band
`N ≥ N_min = 1,333,804,249` it is maximal at `N_min`.

**Gate:** pick constants from the ledger; it suffices to ensure `R(N_min) < 1`.
