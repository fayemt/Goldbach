#!/usr/bin/env python3
import os, sys, time, importlib, argparse
from tqdm import tqdm

# Ensure local directory is on sys.path (robust on Windows double-click or different CWD)
HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

def main():
    ap = argparse.ArgumentParser(description="Run Kuznetsov kernel unit tests with progress")
    ap.add_argument("--module", default="kuz_exact", help="Module exposing build_kernel(q,X,L), W(u), S(m,n,M)")
    args = ap.parse_args()

    try:
        mod = importlib.import_module(args.module)
    except ModuleNotFoundError as e:
        tqdm.write(f"[import] Could not import module '{args.module}'.")
        tqdm.write(f"[import] Current working dir: {os.getcwd()}")
        tqdm.write(f"[import] Script dir (added to sys.path): {HERE}")
        tqdm.write(f"[import] Files in script dir: {', '.join(sorted(os.listdir(HERE)))}")
        raise

    tasks = [
        ("weight_support", None),
        ("symmetry", (5,16,16)),
        ("tiny_manual_case", (3,8,8)),
    ]

    pbar = tqdm(total=len(tasks), desc="Unit tests", ncols=80)
    fail = False

    # Test 1: weight support
    try:
        W = mod.W
        outs = [W(0.0), W(0.49), W(2.01), W(10.0), W(0.6), W(1.0), W(1.8)]
        tqdm.write(f"[weight_support] samples={outs}")
        assert outs[0]==0.0 and outs[1]==0.0 and outs[2]==0.0 and outs[3]==0.0
        assert outs[4]>0 and outs[5]>0 and outs[6]>0
    except Exception as e:
        tqdm.write(f"[weight_support] FAIL: {e}")
        fail = True
    pbar.update(1)

    # Test 2: symmetry
    try:
        q,X,L = tasks[1][1]
        K = mod.build_kernel(q=q, X=X, L=L)
        herm_ok = ( K - K.conj().T )
        max_dev = float(abs(herm_ok).max())
        tqdm.write(f"[symmetry] max |K - K*| = {max_dev:.3e}")
        assert max_dev < 1e-10
    except Exception as e:
        tqdm.write(f"[symmetry] FAIL: {e}")
        fail = True
    pbar.update(1)

    # Test 3: tiny manual case
    try:
        import numpy as np, math
        q,X,L = tasks[2][1]
        def S_direct(m,n,M):
            s = 0.0
            for d in range(1,M):
                if math.gcd(d,M)==1:
                    s += math.cos(2*math.pi*(m*pow(d,-1,M)+n*d)/M)
            return s
        def Wloc(u):
            if u<=0.5 or u>=2.0: return 0.0
            a=u-0.5; b=2.0-u
            return math.exp(-1.0/(a*a)-1.0/(b*b))/math.exp(-5.0)
        K = np.zeros((X,X), dtype=np.float64)
        for c in range(max(1,L//2), 2*L+1):
            M = c*q
            w = 1.0/(M)
            for m in range(1,X+1):
                for n in range(1,X+1):
                    u = (4.0*math.pi*math.sqrt(m*n))/M
                    K[m-1,n-1] += w * Wloc(u) * S_direct(m,n,M)
        K = 0.5*(K+K.T)
        K2 = mod.build_kernel(q=q, X=X, L=L).real
        max_diff = float((abs(K - K2)).max())
        tqdm.write(f"[tiny_manual_case] max |K_direct - K_impl| = {max_diff:.3e}")
        assert max_diff < 1e-9
    except Exception as e:
        tqdm.write(f"[tiny_manual_case] FAIL: {e}")
        fail = True
    pbar.update(1)

    pbar.close()
    if fail:
        tqdm.write("TEST SUITE: FAIL")
        sys.exit(1)
    else:
        tqdm.write("TEST SUITE: PASS")

if __name__ == "__main__":
    main()
