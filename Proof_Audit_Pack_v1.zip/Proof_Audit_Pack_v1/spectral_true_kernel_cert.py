#!/usr/bin/env python3
import argparse, time, math, numpy as np
from math import gcd
from tqdm import tqdm

def W(u: float) -> float:
    if u <= 0.5 or u >= 2.0:
        return 0.0
    a = u - 0.5; b = 2.0 - u
    return math.exp(-1.0/(a*a) - 1.0/(b*b)) / math.exp(-5.0)

def build_kernel(q:int, X:int, L:int) -> np.ndarray:
    # Hermitian geometric kernel (complex), then symmetrize
    two_pi = 2.0*math.pi
    m = np.arange(1, X+1, dtype=np.float64)
    n = np.arange(1, X+1, dtype=np.float64)
    MN = np.sqrt(np.outer(m, n))  # sqrt(mn)

    K = np.zeros((X,X), dtype=np.complex128)
    c_start = max(1, int(0.5*L))
    c_end   = int(2.0*L)
    for c in tqdm(range(c_start, c_end+1), desc=f"c-sum q={q},X={X},L={L}", ncols=80):
        M = c*q
        units = [d for d in range(1, M) if gcd(d,M)==1]
        invs  = [pow(d, -1, M) for d in units]
        u = np.array(units, dtype=np.int64); v = np.array(invs, dtype=np.int64)
        z = np.exp(1j * np.outer(u, np.arange(1,X+1)) * (two_pi/M))
        w = np.exp(1j * np.outer(v, np.arange(1,X+1)) * (two_pi/M))
        S = (z.conj().T @ w)  # complex
        U = (4.0*math.pi*MN)/(M)
        # Apply weight
        Wmat = np.vectorize(W)(U).astype(np.float64)
        K += (S * Wmat) / (M)
    K = 0.5*(K + K.conj().T)
    return K

def power_method_lambda_max(A, iters=200, tol=1e-10, report_every=5, threshold=None):
    X = A.shape[0]
    x = np.random.default_rng(0).standard_normal(X) + 1j*np.random.default_rng(1).standard_normal(X)
    x = x / np.linalg.norm(x)
    lam_old = 0.0
    for it in range(1, iters+1):
        y = A @ x
        lam = float(np.vdot(x, y).real)
        x = y / (np.linalg.norm(y) + 1e-300)
        if it % report_every == 0:
            print(f"[power] iter={it:4d}  lambda~{lam:.6e}")
            if threshold is not None and lam > threshold:
                print(f"[power] EARLY-FAIL: lambda {lam:.6e} exceeded threshold {threshold:.6e}")
                return lam, it, False
        if abs(lam - lam_old) < tol*max(1.0, abs(lam)):
            print(f"[power] converged in {it} iters: lambda~{lam:.6e}")
            return lam, it, True
        lam_old = lam
    print(f"[power] max iters reached: lambda~{lam:.6e}")
    return lam, iters, False

def main():
    ap = argparse.ArgumentParser(description="Exact geometric kernel estimator with progress and iterative lambda display")
    ap.add_argument("--q", default="3,5,12", help="levels (comma sep)")
    ap.add_argument("--X", default="24,32,48", help="matrix sizes (comma sep)")
    ap.add_argument("--L", default="48,64,96", help="c-window lengths (comma sep)")
    ap.add_argument("--mode", choices=["exact","power"], default="exact", help="use dense eigensolver or iterative power method")
    ap.add_argument("--iters", type=int, default=200, help="power method iterations")
    ap.add_argument("--tol", type=float, default=1e-10, help="power method tolerance")
    ap.add_argument("--threshold", type=float, default=None, help="early abort if lambda exceeds this (absolute)")
    ap.add_argument("--cstar_threshold", type=float, default=None, help="early abort if C* exceeds this; needs X,L")
    args = ap.parse_args()

    qs = [int(x) for x in args.q.split(",") if x.strip()]
    Xs = [int(x) for x in args.X.split(",") if x.strip()]
    Ls = [int(x) for x in args.L.split(",") if x.strip()]

    for q in qs:
        for X in Xs:
            for L in Ls:
                print(f"\n[case] q={q} X={X} L={L}")
                K = build_kernel(q,X,L)
                if args.mode == "exact":
                    w = np.linalg.eigvalsh(K.real)  # Hermitian real part bounds the norm
                    lam = float(w[-1])
                    print(f"[exact] lambda_max={lam:.6e}")
                else:
                    # Determine threshold in lambda units if cstar_threshold is given
                    lam_thresh = args.threshold
                    if args.cstar_threshold is not None:
                        lam_thresh = args.cstar_threshold * (X + L*L)
                        print(f"[power] derived lambda threshold from C*: {lam_thresh:.6e}")
                    lam, iters, ok = power_method_lambda_max(K, iters=args.iters, tol=args.tol, threshold=lam_thresh)
                Cstar = lam / (X + L*L)
                print(f"[case] C* = {Cstar:.6e}  (lambda={lam:.6e}, X+L^2={X + L*L})")
                if args.cstar_threshold is not None and Cstar > args.cstar_threshold:
                    print(f"[case] EARLY-FAIL: C* {Cstar:.6e} > threshold {args.cstar_threshold:.6e}")
                    return 2

if __name__ == "__main__":
    main()
