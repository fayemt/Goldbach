# 04 — Type-I Margin (same W, same palette)

We smooth the major-arc side with the **same** weight `W` and restrict to the same finite palette `q ∈ {3,…,12}`. Using explicit bounds for primes in APs (your tables) and standard Mertens-type estimates, one obtains for all `N ≥ N_min`:
```
Margin(N) ≥ c_I * N / (log N)^2,
```
with `c_I = 0.33403` for our setup.

Notes ensuring apples-to-apples:
- same `W` on both sides,
- same palette q,
- AP constants from your file `c_all_rounded.txt` are tiny (max c_theta ≤ 6.829e-4 on the palette),
- the resulting Margin is *increasing* in N on our band, so the left endpoint is the worst case.
