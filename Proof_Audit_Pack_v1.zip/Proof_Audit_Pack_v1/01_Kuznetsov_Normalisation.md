# 01 — Exact Kuznetsov Normalisation (what we certify)

## Test and window (fixed)
- Weight `W ∈ C_c^∞([1/2,2])`, nonnegative, `W(1)=1`. We fix
  `W(u)=exp(-1/(u-1/2)^2 - 1/(2-u)^2) / exp(-5)` for `u∈(1/2,2)` and `0` outside.
- For each small level `q ∈ {3,…,12}` and scale `N`, set `L := N^{1/3}/(4q)`.

## Geometric kernel on Γ₀(q)
For integers `m,n ≥ 1`,
```
K_q(m,n) = ∑_{c≥1} S(m,n; c q) / (c q) * W( 4π√(mn) / (c q) ).
```
This is Hermitian once nebentypus/oldforms are included; in code, form `K` complex and work with `(K+K*)/2`.

## Quadratic form and spectral constant
For `a = (a_1,…,a_X)`,
```
Q_q[a] = ∑_{m,n≤X} a_m * K_q(m,n) * conj(a_n).
```
Define the *scale-free* constant
```
C*(q;X,L) := ||K_q||_{ℓ²→ℓ²} / (X + L²).
```
**This is the object to certify.** By Kuznetsov, `Q_q` equals the full spectral side (holomorphic + Maass + Eisenstein) with the *same* test `W`, so bounding `||K_q||` bounds the entire spectral contribution.
