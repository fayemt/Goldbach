# kuz_exact.py  (patched)
# Exact geometric kernel for Kuznetsov on Γ0(q) with fixed weight W.
# Correct assembly of S(m,n;M): S_mat = Zm @ Zu (NO conjugate), where
#   Zm[m,k] = exp(2π i * m * v_k / M),  Zu[k,n] = exp(2π i * n * u_k / M)

import numpy as np, math
from math import gcd

def W(u: float) -> float:
    if u <= 0.5 or u >= 2.0:
        return 0.0
    a = u - 0.5; b = 2.0 - u
    return math.exp(-1.0/(a*a) - 1.0/(b*b)) / math.exp(-5.0)

def S(m: int, n: int, M: int) -> complex:
    """Reference scalar Kloosterman sum (slow, exact) for spot checks."""
    s = 0.0 + 0.0j
    two_pi_over_M = 2.0*math.pi / M
    for d in range(1, M):
        if gcd(d, M) == 1:
            dinv = pow(d, -1, M)
            ang = two_pi_over_M * (m*dinv + n*d)
            s += complex(math.cos(ang), math.sin(ang))
    return s

def build_kernel(q: int, X: int, L: int) -> np.ndarray:
    """Return Hermitian geometric kernel K (complex) on indices 1..X.
    K[m-1,n-1] = sum_{c in [L/2,2L]} S(m,n;cq)/(cq) * W( 4π√(mn)/(cq) ).
    """
    idx = np.arange(1, X+1, dtype=np.float64)
    MN = np.sqrt(np.outer(idx, idx))  # sqrt(mn)
    K = np.zeros((X, X), dtype=np.complex128)

    c_start = max(1, int(0.5*L))
    c_end   = int(2.0*L)
    for c in range(c_start, c_end+1):
        M = c*q
        two_pi_over_M = 2.0*math.pi / M

        # Weight matrix W(4π√(mn)/M)
        U = (4.0*math.pi*MN)/M
        Wmat = np.vectorize(W)(U).astype(np.float64)
        if np.all(Wmat==0.0):
            continue

        # Units mod M and inverses
        units = [d for d in range(1, M) if math.gcd(d, M)==1]
        invs  = [pow(d, -1, M) for d in units]
        u = np.array(units, dtype=np.int64)     # d_k
        v = np.array(invs, dtype=np.int64)      # d_k^{-1}

        # Build Zm (X × φ(M)): Zm[m,k] = exp(2π i * m * v_k / M)
        Zm = np.exp(1j * np.outer(np.arange(1, X+1), v) * two_pi_over_M)

        # Build Zu (φ(M) × X): Zu[k,n] = exp(2π i * n * u_k / M)
        Zu = np.exp(1j * np.outer(u, np.arange(1, X+1)) * two_pi_over_M)

        # Assemble S matrix by summing over units: S_mat = Zm @ Zu
        S_mat = Zm @ Zu

        # Accumulate with 1/(cq) = 1/M and geometric weight
        K += (S_mat * Wmat) / M

    # Symmetrize to kill tiny FP skew and enforce Hermitian
    K = 0.5*(K + K.conj().T)
    return K
