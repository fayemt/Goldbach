# Proof Audit Pack v0

**Date:** 2025-08-16T06:39:01.116066Z

This pack collects the definitions, constants, and verification steps that reduce the proof to a single, auditable inequality. It is designed to be *paranoid-grade*:
- exact Kuznetsov geometric kernel (no proxy),
- one-log Heath–Brown (k=3) coefficient bound with explicit constants,
- skew-dyad audit,
- Type-I margin aligned to the same weight `W`,
- a single "ratio gate" inequality with a threshold for the certified spectral constant `C*_max`,
- scripts to recompute the gate and check monotonicity analytically.

Contents:
- `01_Kuznetsov_Normalisation.md`
- `02_HB_k3_Coefficient_Bound.md`
- `03_Skew_Dyads.md`
- `04_TypeI_Margin.md`
- `05_Ratio_Gate.md`
- `constants_ledger_draft.csv`
- `rmax_calculator.py`
- `monotonicity_derivation.txt`
- `W_moments.txt`

When a certified bound for the exact geometric kernel is available (the only missing dial), place it into `constants_ledger_draft.csv` under `C_star_max_certified` and run:

```
python rmax_calculator.py --ledger constants_ledger_draft.csv
```

It will print `PASS` or `FAIL` for the worst point `N_min`. Because the ratio is strictly decreasing for `N ≥ e^9`, a pass at `N_min = 1,333,804,249` implies a pass for all larger `N`.
